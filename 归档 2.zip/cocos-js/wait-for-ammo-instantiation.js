System.register(["./instantiated-b8facbde.js"],(function(t){"use strict";return{setters:[function(e){t("default",e.hg)}],execute:function(){}}}));
