System.register([],(function(e,t){"use strict";return{execute:function(){e("default",new URL("assets/bullet.wasm-c98527b6.wasm",t.meta.url).href)}}}));
